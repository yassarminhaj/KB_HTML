# KB_HTML

1-Jan-2023
----------

-> Have spent a week long effort accross a month to get a html website for knowledge base built last year december.
-> Have written down the ID generator logic. The test works fine just a bit of tweeking on feild validations and popup info needs to be done.

5-Nov-2023
-----------

-> Have worked on the mechanism to integrate with flask, to be able to convert it to a CMS. Hence commiting to git so this can be pulled into other pcs and worked on.
