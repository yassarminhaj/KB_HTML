1-Jan-2023
----------

-> Have spent a week long effort accross a month to get a html website for knowledge base built last year december.
-> Have written down the ID generator logic. The test works fine just a bit of tweeking on feild validations and popup info needs to be done.
